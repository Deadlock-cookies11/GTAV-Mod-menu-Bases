# Base
 A mod menu base for Grand Theft Auto V. Strictly for educational purposes, This was made in about 3 days, and has no apparent issues.
 I'm still working on it so please keep that in mind.

# License:
- This project is licensed under the MIT License
- Please visit https://opensource.org/licenses/MIT for all terms and conditions related to this project.

# Issues
- You'll need to do some things yourself, such as adding more rage classes

# Projects used
- MinHook (github.com/TsudaKageyu/minhook)

# Info
- This base is made for Gta verison 1.69
- This is made in C++, so try not to judge the code too much. It's my first base
- Native hooking 
- Simple Fiber system 
- Aligned interface 
- Unloading at runtime

# Compiling
```bash
git clone https://github.com/TxL02/base-txl
```
put on build mode to rel and build
# Contacts
Email - txleee@proton.me
Discord - TxL#1337(941341754383273984) , Purgatory#1604(1063481187445784639)
